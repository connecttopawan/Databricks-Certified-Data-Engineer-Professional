# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Lab: Data Skipping and Liquid Clustering
# MAGIC
# MAGIC In this demo, we are going to work with Liquid Clustering, a Delta Lake optimization feature that replaces table partitioning and ZORDER to simplify data layout decisions and optimize query performance. It provides flexibility to redefine clustering keys without rewriting data. Refer to the [documentation](https://docs.databricks.com/en/delta/clustering.html) for more information.
# MAGIC
# MAGIC #### Learning Objectives
# MAGIC **By the end of this lab, you will be able to:**
# MAGIC
# MAGIC * Disable Spark caching to observe the effects of Liquid Clustering.
# MAGIC * Count records and explore data in the `flights` table.
# MAGIC * Execute queries on an unclustered table and analyze their performance using Spark UI.
# MAGIC * Execute and compare queries on tables clustered by different columns (`id` and `id` + `FlightNum`).
# MAGIC * Inspect query performance using the Spark UI to understand the benefits of Liquid Clustering.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Prerequisites
# MAGIC In order to follow along with this lab, you will need:
# MAGIC
# MAGIC
# MAGIC * If this course is being led by an instructor, the necessary tables will already be set up.
# MAGIC * Basic knowledge of running SQL queries in Databricks is required.
# MAGIC * Familiarity with Delta Lake and its optimization features is recommended.
# MAGIC * If you are taking this course as a **self-paced course**, you will need to run the [**Flight Data Generation**]($./Includes/Flight Data Generation) notebook first.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Getting Started
# MAGIC Run the next cell to set up the lesson.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-01.2L

# COMMAND ----------

# MAGIC %md
# MAGIC ## Lab Tasks
# MAGIC The major tasks essential to be carried out for this lab are listed below:
# MAGIC 1. **Task 1:** Review and Explore the `flights` Table.
# MAGIC 2. **Task 2:** Explore Liquid Clustering and understand how it works.
# MAGIC 3. **Task 3:** Inspecting the tables with and without clustering, using Spark UI to identify that data is skipped at the source.
# MAGIC
# MAGIC
# MAGIC **Note:** The cells marked as **TODO** need to be completed thoroughly by the students.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Task 1: Review and Explore the flights Table.
# MAGIC
# MAGIC Perform the following operations:
# MAGIC 1. **Step 1:** Disable Caching
# MAGIC 2. **Step 2:** Review the data stored in the `flights` table
# MAGIC 3. **Step 3:** Count the number of `records` in the flights table

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Disable Caching
# MAGIC
# MAGIC Set the required Spark configuration variable to **disable caching**, making the effect of the optimizations more apparent.

# COMMAND ----------

# Set the spark configuration variable "io.cache" as "False"
spark.conf.set('spark.databricks.io.cache.enabled', False)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 2: Review the Data Stored in the Flights Table
# MAGIC Query the flights table to review its records:

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Perform a SELECT operation on the entire flights table.
# MAGIC SELECT * FROM dbacademy.flights

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Count the Number of Records in the Flights Table
# MAGIC Query the flights table to determine the number of `records` in the flights table:

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Perform a COUNT operation on the entire flights table.
# MAGIC SELECT COUNT(*) FROM dbacademy.flights

# COMMAND ----------

# MAGIC %md
# MAGIC ## TODO
# MAGIC ### Task 2: Explore Liquid Clustering and understand how it works
# MAGIC Delta Lake liquid clustering replaces table partitioning and ZORDER to simplify data layout decisions and optimize query performance. It provides flexibility to redefine clustering keys without rewriting existing data, allowing data layout to evolve alongside analytic needs over time.  
# MAGIC
# MAGIC Databricks recommends liquid clustering for all new Delta tables. Scenarios benefiting from clustering include:
# MAGIC
# MAGIC * Tables often filtered by high cardinality columns.
# MAGIC * Tables with a significant skew in data distribution.
# MAGIC * Tables that grow quickly and require maintenance and tuning effort.
# MAGIC * Tables with concurrent write requirements.
# MAGIC * Tables with access patterns that change over time.
# MAGIC * Tables where a typical partition key could leave the table with too many or too few partitions.
# MAGIC
# MAGIC For more information on how to enable the liquid clustering, refer to the [documentation](https://docs.databricks.com/en/delta/clustering.html#enable-liquid-clustering)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Task 3: Inspecting the tables with and without clustering, using Spark UI to identify that data is skipped at the source.
# MAGIC Querying the following three tables:
# MAGIC
# MAGIC 1. `flights`, which does not use liquid clustering.
# MAGIC 2. `flights_cluster_id`, which is clustered by id.
# MAGIC 3. `flights_cluster_id_flightnum`, which is clustered by `id` and `FlightNum`.
# MAGIC
# MAGIC Perform the following operations:
# MAGIC 1. **Step 1:** Review the Query Performace without using Clustering
# MAGIC 2. **Step 2:** Inspect the Query Performace using Spark UI
# MAGIC 3. **Step 3:** Review the Queries Clustered by ID
# MAGIC 4. **Step 4:** Review the Queries Clustered by ID and FlightNum

# COMMAND ----------

# MAGIC %md
# MAGIC ### Unclustered Table 
# MAGIC   
# MAGIC These queries are already quite fast without using clustering, considering we are using a small cluster, and the tables are 9 GB of data. But there is room for improvement.

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 1: Review the Query Performace without using Clustering
# MAGIC Run the following queries and note the time it takes to run each cell.

# COMMAND ----------

# MAGIC %md
# MAGIC Run the following query to analyze the Average Arrival Delay in flights by the `TW` airline.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Perform the SELECT operation with the AVG operation on the 'ArrDelay' column and the 'UniqueCarrier' set to 'TW'.
# MAGIC SELECT AVG(ArrDelay) FROM dbacademy.flights WHERE UniqueCarrier = 'TW'

# COMMAND ----------

# MAGIC %md
# MAGIC ## TODO
# MAGIC #### Step 2: Inspect the Query Performace using Spark UI
# MAGIC
# MAGIC We will review the query performace metrics using Spark UI
# MAGIC
# MAGIC **Step 2.1**. To access your lab cluster, begin by clicking on the **Compute** tab in the left-side navigation bar. Next, choose the cluster you are using for the labs from the list.
# MAGIC
# MAGIC   ![1](files/images/databricks-performance-optimization-1.2.0/1.2L-Spark_UI_1.png)
# MAGIC
# MAGIC **Step 2.2**. After selecting the cluster, navigate to the **Spark UI** tab on the compute details page to access detailed performance information of the queries.
# MAGIC
# MAGIC   ![1](files/images/databricks-performance-optimization-1.2.0/1.2L-Spark_UI_2.png)
# MAGIC
# MAGIC **Step 2.3**. After reaching the Spark UI page, Navigate to the Spark UI page and click on the **SQL/DataFrame** tab.
# MAGIC
# MAGIC   ![1](files/images/databricks-performance-optimization-1.2.0/1.2L-Spark_UI_3.png)
# MAGIC
# MAGIC **Step 2.4**. After navigating to the SQL/DataFrame tab, search for the SQL query you want to analyze, click on it, and then explore its performance metrics using the Spark UI.
# MAGIC
# MAGIC   ![1](files/images/databricks-performance-optimization-1.2.0/1.2L-Spark_UI_5.png)
# MAGIC
# MAGIC **Step 2.5**. Once you select the query, different performance metrics will appear. This section provides an overview to explore these performance metrics.
# MAGIC
# MAGIC   ![1](files/images/databricks-performance-optimization-1.2.0/1.2L-Spark_UI_4.png)

# COMMAND ----------

# MAGIC %md
# MAGIC Run the following query to analyze the Average Arrival Delay by flights number `1809`.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Perform the SELECT operation with the AVG operation on the 'ArrDelay' column and the 'FlightNum' set to '1890'.
# MAGIC SELECT AVG(ArrDelay) FROM dbacademy.flights WHERE FlightNum = 1890

# COMMAND ----------

# MAGIC %md
# MAGIC ### TODO
# MAGIC **Question:** Why did this query complete quickly compared to the one above?

# COMMAND ----------

# MAGIC %md
# MAGIC Run the following query to analyze the records in the flight table having the id `1125281431554`.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dbacademy.flights WHERE id = 1125281431554

# COMMAND ----------

# MAGIC %md
# MAGIC ### TODO
# MAGIC
# MAGIC For above Query, Open the Spark UI to inspect query performance by following same steps as mentioned earlier. In particular, and note the amount of data that had to be pulled from the data store (in the **Input** column)
# MAGIC
# MAGIC ![4](files/images/databricks-performance-optimization-1.2.0/4.2-CMD-17-h.png)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 3: Review the Queries Clustered by ID
# MAGIC Run the following three queries. These queries pull data from the `flights_cluster_id` table. This table is exactly the same as the one we used in the queries above, except that we have enabled liquid clustering by adding `CLUSTER BY (id)` when the table was created.  
# MAGIC   
# MAGIC Note the following:
# MAGIC - When we query by the clustered column (id), we see a significant improvement in query performance
# MAGIC - We don't see a degredation in performance on queries against unclustered columns  
# MAGIC
# MAGIC View the first job in the query that filters by `id` and note the amount of data that was skipped. You can also see in the query plan that the filter was pushed down.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Run the following query to review the Average Arrival Delay in flights by the `TW` airline.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Perform the SELECT operation on the 'flights_cluster_id' table with the AVG operation on the 'ArrDelay' column and the 'UniqueCarrier' set to 'TW'.
# MAGIC SELECT AVG(ArrDelay) FROM dbacademy.flights_cluster_id WHERE UniqueCarrier = 'TW'

# COMMAND ----------

# MAGIC %md
# MAGIC Run the following query to review the Average Arrival Delay by flights number `1809`.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Perform the SELECT operation on the 'flights_cluster_id' table with the AVG operation on the 'ArrDelay' column and the 'FlightNum' set to '1890'.
# MAGIC SELECT AVG(ArrDelay) FROM dbacademy.flights_cluster_id WHERE FlightNum = 1890

# COMMAND ----------

# MAGIC %md
# MAGIC Run the following query to review the records in the `flights_cluster_id` table having the id `1125281431554`.

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dbacademy.flights_cluster_id WHERE id = 1125281431554

# COMMAND ----------

# MAGIC %md
# MAGIC ### TODO
# MAGIC Open the Spark UI to inspect query performance by following same steps as mentioned earlier. In particular, note the cloud storage requests and associated time for table `flight_cluster_id`.
# MAGIC
# MAGIC ![4](files/images/databricks-performance-optimization-1.2.0/4.2-CMD-22-1-h.png)
# MAGIC
# MAGIC Also, notice the sizes of the processed files.
# MAGIC
# MAGIC ![4](files/images/databricks-performance-optimization-1.2.0/4.2-CMD-22-2-h.png)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 4: Review the Queries Clustered by ID and FlightNum
# MAGIC
# MAGIC Run the following three queries. These queries pull data from the `flights_cluster_id_flightnum` table. This table is clustered by both the `id` and `flight_num` columns.  
# MAGIC
# MAGIC Note the following:
# MAGIC - We still don't have any degredation on unclustered columns. Had we used `PARTITION BY` to partition by `flight_num` and `id`, we would see massive slowdown for any queries not on those columns, and writes would be prohibitively slow for this volume of data
# MAGIC - Now queries on flight number are improved
# MAGIC - Queries are a little slower on id now, however and we can look at the DAG to see why.
# MAGIC
# MAGIC Note that, because  we had to read more files to satisfy this request. There is a (small) cost to clustering on more columns, so choose wisely.

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Run the following query to review the records of **Average Arrival Delay by Unique Carrier** on `flights_cluster_id_flightnum` table

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT AVG(ArrDelay) FROM dbacademy.flights_cluster_id_flightnum WHERE UniqueCarrier = 'TW'

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Run the following query to review the records of **Average Arrival Delay by Flight Number** on `flights_cluster_id_flightnum` table

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT AVG(ArrDelay) FROM dbacademy.flights_cluster_id_flightnum WHERE FlightNum = 1890

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Run the following query to review the records of **Select Specific Record by ID** on `flights_cluster_id_flightnum` table

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM dbacademy.flights_cluster_id_flightnum WHERE id = 1125281431554

# COMMAND ----------

# MAGIC %md
# MAGIC ### TODO
# MAGIC **Question:** Why the above query is faster than baseline table query but slower than the previous command cluster by id table?

# COMMAND ----------

# MAGIC %environment
# MAGIC "client": "1"
# MAGIC "base_environment": ""

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC &copy; 2024 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the 
# MAGIC <a href="https://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/><a href="https://databricks.com/privacy-policy">Privacy Policy</a> | 
# MAGIC <a href="https://databricks.com/terms-of-use">Terms of Use</a> | 
# MAGIC <a href="https://help.databricks.com/">Support</a>