# Databricks notebook source
# MAGIC %run ./Classroom-Setup-01-Common

# COMMAND ----------

DA = init_DA("1.1")